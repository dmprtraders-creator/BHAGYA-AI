// Tabs navigation
document.addEventListener('DOMContentLoaded', ()=>{
  const tabs = document.querySelectorAll('.tab');
  const panels = document.querySelectorAll('.panel');
  tabs.forEach(t=> t.addEventListener('click', ()=>{
    tabs.forEach(x=>x.classList.remove('active'));
    panels.forEach(p=>p.classList.remove('active'));
    t.classList.add('active');
    const id = t.getAttribute('data-target');
    const panel = document.getElementById(id);
    if(panel) panel.classList.add('active');
  }));

  // Enquiry form handling (demo)
  const enquiry = document.getElementById('enquiryForm');
  if(enquiry) enquiry.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = new FormData(enquiry);
    const obj = Object.fromEntries(data.entries());
    alert('Enquiry captured:\nName: '+obj.name+'\nPhone: '+obj.phone+'\nService: '+obj.service);
    enquiry.reset();
  });

  // EMI Calculator
  const calcBtn = document.getElementById('calcBtn');
  function toNum(id){const el=document.getElementById(id);return el?Number(el.value||0):0}
  function show(id,val){const el=document.getElementById(id);if(el)el.textContent=val}
  if(calcBtn){
    calcBtn.addEventListener('click',(ev)=>{
      ev.preventDefault();
      const income = toNum('income');
      const obligations = toNum('obligations');
      const loan = toNum('loanAmount');
      const annualRate = toNum('rate');
      const years = toNum('tenure');
      const isCar = document.getElementById('isCar').checked;

      // Net eligibility per user rule: 60% of (total net monthly earning - running obligation)
      const netAvailable = Math.max(0, income - obligations);
      const netEligibility = 0.6 * netAvailable;

      // FOIR: default 60% else 100% for car loans per user note
      const foir = isCar ? 1.0 : 0.6;

      // EMI formula
      const monthlyRate = annualRate/100/12;
      const n = Math.max(1, years*12);
      let emi = 0;
      if(monthlyRate>0){
        const r = monthlyRate;
        emi = loan * r * Math.pow(1+r,n) / (Math.pow(1+r,n)-1);
      } else {
        emi = loan / n;
      }

      show('eligibility', '₹ ' + netEligibility.toFixed(2));
      show('emiValue', emi>0 ? '₹ ' + emi.toFixed(2) : '-');
      show('foir', (foir*100).toFixed(0)+'%');

      // Eligibility note
      const eligNote = document.getElementById('eligNote');
      if(emi>0){
        if(netEligibility >= emi){
          eligNote.textContent = 'You are eligible: your 60% net income after obligations covers the EMI.';
        } else {
          eligNote.textContent = 'You may not be eligible: EMI exceeds 60% net-of-obligation income. Consider lower amount/longer tenure.';
        }
      } else {
        eligNote.textContent = 'Enter loan details to compute EMI.';
      }
    });
  }
});
